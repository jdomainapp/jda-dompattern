`CargoShipping` domain model
==============================

## Assets
1. Project: `module-dompattern`
2. Domain model: $DOM = `jda.modules.patterndom.test.dom.cargoshipping.domain.model.cargo`
   1. 4 key domain classes (current version): `Cargo`, `Delivery`, `Itinerary`, `RouteSpecification`
   2. subpackage `bak`: contains original versions fo the 4 key domain classes (above). These are used as input for the `TGCargoShipping` app
   3. Code adaption for class `Cargo`: `Cargo_CodeAdaptationAfterTransform.java`. This is used after `Cargo` has been transformed from by `TGCargoShipping` app