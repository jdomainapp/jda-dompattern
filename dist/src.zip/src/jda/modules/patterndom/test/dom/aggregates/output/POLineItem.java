package jda.modules.patterndom.test.dom.aggregates.output;

/**
 * @overview 
 *
 * @author Duc Minh Le (ducmle)
 *
 * @version 
 */
public class POLineItem {
   
}
