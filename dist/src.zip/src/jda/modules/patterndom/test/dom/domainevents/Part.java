package jda.modules.patterndom.test.dom.domainevents;

/**
 * @overview 
 *
 * @author Duc Minh Le (ducmle)
 *
 * @version 
 */
public class Part {

  public Part() {
    System.out.println("Part initialised...");
  }
}
