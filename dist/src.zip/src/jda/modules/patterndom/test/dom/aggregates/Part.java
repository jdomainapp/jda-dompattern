package jda.modules.patterndom.test.dom.aggregates;

/**
 * @overview 
 *
 * @author Duc Minh Le (ducmle)
 *
 * @version 
 */
public class Part {

}
