package jda.modules.patterndom.test.dom.factory;

/**
 * @overview 
 *
 * @author Duc Minh Le (ducmle)
 *
 * @version 
 */
public class Part {

}
