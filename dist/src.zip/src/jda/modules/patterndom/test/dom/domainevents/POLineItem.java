package jda.modules.patterndom.test.dom.domainevents;

/**
 * @overview 
 *
 * @author Duc Minh Le (ducmle)
 *
 * @version 
 */
public class POLineItem {

  public POLineItem() {
    System.out.println("POLineItem initialised...");
  }
}
